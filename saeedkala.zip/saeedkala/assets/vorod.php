﻿<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>ورود به حسین کالا</title>
			<?php require('dbcon.php'); ?>
			
	</head>
	<body bgcolor='#C5FFFA'>
	<center>
<br>
<br>
<a onClick="history.go(-1)"><img src='your_logo.png' class='logo' alt='logo' /></a >
<br>
<br>
<br>
<br>
<br>
<br>
<div style="width:300px; border-style:solid">
<div style="font-family: B Nazanin">
<div style="font-size: 28px">
		<form method="post" action="login.php">
							<h3>ورود</h3> 
</div>
								<input type="text" name="username" placeholder="نام کاربری" required> <br><br>
                                <input name="password" type="password" placeholder="رمز ورود" required >     <br><br>  
                               <button type="submit" name="login">ورود</button>
		</form>
</center>
<br>
<br>
</div>
</div>
	</body>
</html>